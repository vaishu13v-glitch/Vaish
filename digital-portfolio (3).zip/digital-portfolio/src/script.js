// Footer year
document.getElementById("year").textContent = new Date().getFullYear();

// Contact form
const form = document.getElementById("contactForm");
const msg = document.getElementById("formMessage");

form.addEventListener("submit", function(event) {
  event.preventDefault();
  msg.textContent = "Thank you for your message, Vaishnavi will reply soon! ✅";
  form.reset();
});